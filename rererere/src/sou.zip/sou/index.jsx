import React, { Component } from 'react'
import './index.scss'
export default class Html extends Component {
    constructor(){
        super()
        this.state= {
            list:[],
            isblock:true,
            block:true,
            isblock1:true

        }
    }
   
    bloackClick = ()=> {
      
        this.setState({
          isblock: !this.state.isblock,
          block:!this.state.block,
          
        })
        
      }
    render() {
        return (
            <div className='s'>

                <div className='flex'>

                    <div  onClick={this.bloackClick} className={this.state.isblock ? 'sou' : ' sousou'} >

                            <div className='icon'> <i className='iconfont icon-search'></i></div>

                            <input type='text' placeholder='搜索知乎内容'/>
                    </div>

                    <div  onClick={this.bloackClick} className={this.state.isblock ? 'none' : ' block'}>取消</div>
               
                </div>
                    
                <div className={this.state.isblock ? 'none' : ' block'}>
                    


                    <img src={ `${process.env.PUBLIC_URL}/zhihuimg/热搜.png` } alt='book' />

                </div>

            </div>
        )
    }
}
